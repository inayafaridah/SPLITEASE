// providers/settlement_provider.dart
import 'package:flutter/material.dart';
import '../models/settlement.dart';
import '../db/settlement_dao.dart';

class SettlementProvider extends ChangeNotifier {
  final SettlementDao _dao = SettlementDao();

  List<Settlement> _settlements = [];
  bool _loading = false;
  String? _error;
  int? _currentGroupId;

  List<Settlement> get settlements => _settlements;
  bool get loading => _loading;
  String? get error => _error;

  // Hapus semua getter pending dan markPaid.

  Future<void> loadByGroup(int groupId) async {
    _loading = true;
    _currentGroupId = groupId;
    _error = null;
    notifyListeners();
    try {
      _settlements = await _dao.getByGroup(groupId);
    } catch (e) {
      _error = e.toString();
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<int> add(Settlement settlement) async {
    final id = await _dao.insert(settlement);
    if (_currentGroupId != null) await loadByGroup(_currentGroupId!);
    return id;
  }

  Future<void> updateSettlement(Settlement settlement) async {
    await _dao.update(settlement);
    if (_currentGroupId != null) await loadByGroup(_currentGroupId!);
  }

  Future<void> remove(int id) async {
    await _dao.delete(id);
    if (_currentGroupId != null) await loadByGroup(_currentGroupId!);
  }
}