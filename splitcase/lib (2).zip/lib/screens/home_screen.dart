// lib/screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../models/group.dart';
import '../providers/group_provider.dart';
import '../providers/contact_provider.dart';
import '../providers/group_member_provider.dart';
import 'group_detail_screen.dart';
import 'add_contact_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<GroupProvider>().loadAll();
      context.read<ContactProvider>().loadAll();
    });
  }

  void _showAddGroupDialog(BuildContext context) {
    final nameCtrl = TextEditingController();
    String currency = 'IDR';
    List<int> selectedContactIds = [];

    showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (ctx, setLocal) {
          final cp = context.read<ContactProvider>();

          return AlertDialog(
            title: const Text('Buat Grup Baru'),
            content: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameCtrl,
                      decoration: const InputDecoration(
                        labelText: 'Nama Grup',
                        hintText: 'Dinner Fancy Bali',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: currency,
                      decoration: const InputDecoration(
                        labelText: 'Mata Uang',
                        border: OutlineInputBorder(),
                      ),
                      items: ['IDR', 'USD', 'EUR']
                          .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                          .toList(),
                      onChanged: (v) => setLocal(() => currency = v ?? 'IDR'),
                    ),
                    const SizedBox(height: 16),
                    const Text('Pilih Anggota', style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    cp.contacts.isEmpty
                        ? const Text('Tambah kontak terlebih dahulu')
                        : Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: cp.contacts.map((c) {
                              final isSelected = selectedContactIds.contains(c.id);
                              return FilterChip(
                                label: Text(c.name),
                                selected: isSelected,
                                onSelected: (sel) {
                                  setLocal(() {
                                    if (sel) {
                                      selectedContactIds.add(c.id!);
                                    } else {
                                      selectedContactIds.remove(c.id);
                                    }
                                  });
                                },
                              );
                            }).toList(),
                          ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Batal'),
              ),
              ElevatedButton(
                onPressed: () async {
                  final name = nameCtrl.text.trim();
                  if (name.isEmpty) {
                    ScaffoldMessenger.of(dialogContext).showSnackBar(
                      const SnackBar(content: Text('Nama grup tidak boleh kosong')),
                    );
                    return;
                  }

                  Navigator.pop(dialogContext); // Tutup dialog

                  final gp = context.read<GroupProvider>();
                  final gmp = context.read<GroupMemberProvider>();

                  try {
                    final groupId = await gp.add(Group(name: name, currency: currency));

                    if (selectedContactIds.isNotEmpty) {
                      await gmp.addMembers(groupId, selectedContactIds);
                    }

                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Grup berhasil dibuat ✓')),
                      );
                      gp.loadAll();
                    }
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Gagal: $e')),
                      );
                    }
                  }
                },
                child: const Text('Buat'),
              ),
            ],
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final gp = context.watch<GroupProvider>();
    final cp = context.watch<ContactProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Splitage'),
        actions: [
          IconButton(
            icon: const Icon(Icons.people),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddContactScreen()),
            ),
          ),
        ],
      ),
      body: gp.loading
          ? const Center(child: CircularProgressIndicator())
          : gp.groups.isEmpty
              ? _buildEmpty(context)
              : _buildList(context, gp, cp),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddGroupDialog(context),
        icon: const Icon(Icons.add),
        label: const Text('Grup Baru'),
      ),
    );
  }

  Widget _buildEmpty(BuildContext context) => const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.group_outlined, size: 80, color: Colors.grey),
            SizedBox(height: 16),
            Text('Belum ada grup', style: TextStyle(fontSize: 18)),
            Text('Buat grup untuk mulai split tagihan', style: TextStyle(color: Colors.grey)),
          ],
        ),
      );

  Widget _buildList(BuildContext context, GroupProvider gp, ContactProvider cp) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: gp.groups.length,
      itemBuilder: (ctx, i) {
        final group = gp.groups[i];
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Theme.of(context).colorScheme.primary,
              child: Text(group.name[0].toUpperCase()),
            ),
            title: Text(group.name, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text(DateFormat('dd MMM yyyy').format(DateTime.parse(group.createdAt))),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => GroupDetailScreen(group: group)),
            ).then((_) => gp.loadAll()),
            onLongPress: () => _showGroupOptions(context, group, gp),
          ),
        );
      },
    );
  }

  void _showGroupOptions(BuildContext context, Group group, GroupProvider gp) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('Edit Grup'),
            onTap: () {
              Navigator.pop(ctx);
              _showEditGroupDialog(context, group, gp);
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete, color: Colors.red),
            title: const Text('Hapus Grup', style: TextStyle(color: Colors.red)),
            onTap: () {
              Navigator.pop(ctx);
              _confirmDelete(context, group, gp);
            },
          ),
        ],
      ),
    );
  }

  void _showEditGroupDialog(BuildContext context, Group group, GroupProvider gp) {
    final nameCtrl = TextEditingController(text: group.name);
    String currency = group.currency;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit Grup'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Nama Grup')),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: currency,
              items: ['IDR', 'USD', 'EUR'].map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
              onChanged: (v) => currency = v ?? 'IDR',
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          ElevatedButton(
            onPressed: () async {
              await gp.rename(group.id!, nameCtrl.text.trim(), currency: currency);
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, Group group, GroupProvider gp) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus Grup?'),
        content: Text('Semua transaksi dan data di "${group.name}" akan dihapus permanen.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              await gp.remove(group.id!);
              if (ctx.mounted) Navigator.pop(ctx);
            },
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }
}