// lib/screens/history_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/settlement.dart';
import '../providers/settlement_provider.dart';
import '../providers/transaction_provider.dart';
import '../providers/contact_provider.dart';
import 'settle_screen.dart';
import '../utils/currency_formatter.dart'; 

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({Key? key}) : super(key: key);

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  @override
  Widget build(BuildContext context) {
    final tp = context.watch<TransactionProvider>();
    final cp = context.watch<ContactProvider>();
    final sp = context.watch<SettlementProvider>();

    final groupId = tp.currentGroupId ?? 0;
    final currentSettlements = sp.settlements.where((s) => s.groupId == groupId).toList();

    // Hitung ringkasan total uang yang sudah lunas dibayar di grup ini untuk grafik bulat
    double totalSettled = currentSettlements.fold(0.0, (sum, item) => sum + item.amount);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Riwayat Pembayaran'),
      ),
      body: currentSettlements.isEmpty
          ? const Center(
              child: Text(
                'Belum ada riwayat pembayaran.',
                style: TextStyle(color: Colors.grey),
              ),
            )
          : Column(
              children: [
                // --- GRAFIK BULAT HISTORY (PROGRESS KONTRIBUSI) ---
                Container(
                  margin: const EdgeInsets.all(16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.1),
                        blurRadius: 10,
                        spreadRadius: 2,
                      )
                    ],
                  ),
                  child: Row(
                    children: [
                      // Komponen Visual Grafik Bulat Lingkaran
                      Stack(
                        alignment: Alignment.center,
                        children: [
                          SizedBox(
                            width: 75,
                            height: 75,
                            child: CircularProgressIndicator(
                              value: totalSettled > 0 ? 1.0 : 0.0,
                              strokeWidth: 8,
                              backgroundColor: Colors.grey.shade200,
                              valueColor: const AlwaysStoppedAnimation<Color>(Colors.green),
                            ),
                          ),
                          const Icon(Icons.donut_large, size: 36, color: Colors.green),
                        ],
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Total Dana Selesai Dibayar',
                              style: TextStyle(fontSize: 13, color: Colors.grey, fontWeight: FontWeight.w500),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Rp ${totalSettled.toStringAsFixed(0)}',
                              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green),
                            ),
                            Text(
                              'Dari ${currentSettlements.length} transaksi pelunasan',
                              style: const TextStyle(fontSize: 11, color: Colors.grey),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                const Divider(height: 1),
                // --- SELESAI GRAFIK ---
                
                Expanded(
                  child: _buildList(context, currentSettlements, cp, groupId),
                ),
              ],
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          if (tp.currentGroupId != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => SettleScreen(groupId: tp.currentGroupId!),
              ),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Grup tidak ditemukan atau belum dipilih.')),
            );
          }
        },
        icon: const Icon(Icons.add),
        label: const Text('Catat'),
      ),
    );
  }

  Widget _buildList(
    BuildContext context,
    List<Settlement> settlements,
    ContactProvider cp,
    int groupId,
  ) {
    final sp = context.read<SettlementProvider>();

    return ListView.builder(
      itemCount: settlements.length,
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemBuilder: (context, index) {
        final s = settlements[index];

        final fromName = cp.contacts
            .where((c) => c.id == s.fromContactId)
            .map((c) => c.name)
            .firstWhere((_) => true, orElse: () => 'Tidak Diketahui');

        final toName = cp.contacts
            .where((c) => c.id == s.toContactId)
            .map((c) => c.name)
            .firstWhere((_) => true, orElse: () => 'Tidak Diketahui');

        return Card(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
          child: ListTile(
            leading: const CircleAvatar(
              backgroundColor: Colors.greenAccent,
              child: Icon(Icons.check, color: Colors.green),
            ),
            title: Text('$fromName → $toName', style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('Jumlah: Rp ${s.amount.toStringAsFixed(0)}'),
            trailing: IconButton(
              icon: const Icon(Icons.more_vert),
              onPressed: () => _settlementOptions(context, s, sp, groupId),
            ),
          ),
        );
      },
    );
  }

  void _settlementOptions(BuildContext ctx, Settlement s, SettlementProvider sp, int groupId) {
    showModalBottomSheet(
      context: ctx,
      builder: (_) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('Edit'),
            onTap: () {
              Navigator.pop(ctx);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => SettleScreen(existing: s, groupId: groupId),
                ),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete, color: Colors.red),
            title: const Text('Hapus', style: TextStyle(color: Colors.red)),
            onTap: () async {
              Navigator.pop(ctx);
              await sp.remove(s.id!); 
            },
          ),
        ],
      ),
    );
  }
}