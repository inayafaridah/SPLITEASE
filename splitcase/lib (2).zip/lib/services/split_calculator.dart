// lib/services/split_calculator.dart
import '../models/transaction.dart';
import '../models/contact.dart';

class DebtEntry {
  final Contact debtor;
  final Contact creditor;
  final double amount;

  DebtEntry({required this.debtor, required this.creditor, required this.amount});
}

class BalanceSummary {
  final Contact contact;
  final double paid;
  final double share;
  double get balance => paid - share;

  BalanceSummary({required this.contact, required this.paid, required this.share});
}

class SplitCalculator {
  static List<DebtEntry> calculate({
    required List<Transaction> transactions,
    required List<Contact> contacts, // Ini nanti dilemparkan list yang sudah difilter anggota grup saja
  }) {
    if (contacts.isEmpty) return [];

    // Inisialisasi map hanya untuk kontak yang masuk dalam grup ini
    final Map<int, double> paid = {for (var c in contacts) c.id!: 0.0};
    
    for (final tx in transactions) {
      // Antisipasi jika ada payer diluar list anggota (safety check)
      if (paid.containsKey(tx.payerContactId)) {
        paid[tx.payerContactId] = (paid[tx.payerContactId] ?? 0) + tx.amount;
      }
    }

    final double total = paid.values.fold(0.0, (a, b) => a + b);
    // Pembagian rata dihitung adil HANYA dibagi jumlah anggota grup aktif
    final double share = total / contacts.length;

    final Map<int, double> balance = {
      for (var c in contacts) c.id!: (paid[c.id!] ?? 0) - share,
    };

    final debtors = balance.entries.where((e) => e.value < -0.01).toList()
      ..sort((a, b) => a.value.compareTo(b.value));

    final creditors = balance.entries.where((e) => e.value > 0.01).toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    final List<DebtEntry> debts = [];
    final contactMap = {for (var c in contacts) c.id!: c};

    int i = 0, j = 0;
    while (i < debtors.length && j < creditors.length) {
      final debt = -debtors[i].value;
      final credit = creditors[j].value;
      final settled = debt < credit ? debt : credit;

      if (settled > 0.01) {
        debts.add(DebtEntry(
          debtor: contactMap[debtors[i].key]!,
          creditor: contactMap[creditors[j].key]!,
          amount: (settled * 100).round() / 100,
        ));
      }

      debtors[i] = MapEntry(debtors[i].key, debtors[i].value + settled);
       creditors[j] = MapEntry(creditors[j].key, creditors[j].value - settled);

      if (debtors[i].value.abs() < 0.01) i++;
      if (creditors[j].value.abs() < 0.01) j++;
    }

    return debts;
  }

  static List<BalanceSummary> balanceSummaries({
    required List<Transaction> transactions,
    required List<Contact> contacts, // Ini juga list yang sudah difilter anggota grup saja
  }) {
    if (contacts.isEmpty) return [];
    
    final Map<int, double> paid = {for (var c in contacts) c.id!: 0.0};
    for (final tx in transactions) {
      if (paid.containsKey(tx.payerContactId)) {
        paid[tx.payerContactId] = (paid[tx.payerContactId] ?? 0) + tx.amount;
      }
    }

    final double total = paid.values.fold(0.0, (a, b) => a + b);
    final double share = total / contacts.length;

    return contacts.map((c) => BalanceSummary(
          contact: c,
          paid: paid[c.id!] ?? 0,
          share: share,
        )).toList();
  }

  static double totalExpense(List<Transaction> transactions) =>
      transactions.fold(0.0, (sum, tx) => sum + tx.amount);
}